# Cobblemon-Added-Recipies
The added recipes datapack for cobblemon 


This datapack currently adds recipes to the XS, S, M, L, and XL candies in cobblemon which are currently unobtainable otherwise.
